package waterplant;

import java.sql.*;
import java.util.*;

public class DB_Part{

   private static String userName = "root";
    private static String password = "Srujan@13";
    private static String hostName = "127.0.0.1";
    private static String dbName = "water_plant";
    private static String url = "jdbc:mysql://" +hostName +":3306/" + dbName+"?autoReconnect=true&useSSL=false";
    private static Connection connection;
    private static String urlString;
    private static String driverName = "com.mysql.cj.jdbc.Driver";

    public static Connection getConnection(){
        try{
            Class.forName(driverName);
            try{
             connection = DriverManager.getConnection(url, userName, password);
             System.out.println(" Connection Successful.");
            }
             catch( SQLException ex){
            //Log an exception
                System.out.println(" Failed to create the database connection. ");
                ex.printStackTrace();
            }
        }catch( ClassNotFoundException ex){
            //logging exception
            System.out.println(" Driver Not Found");            

        }
        return connection;
    }
    
    public static void main(String [] args){
        getConnection();
        System.out.println(url);
    }
}

	/*public static void main(String[] args) {
//....
}
public static Connection getConnection() {
		String userid = "root";
		String password = "Srujan@13";//password
		String hostname = "127.0.0.1";
		String dbName ="water_plant"; //data base 
		String url = "jdbc:mysql://" + hostname + ":3306/" + dbName +"?autoReconnect=true&useSSL=false";
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, userid, password);
		} 
                catch (SQLException ex) {
			System.out.println("Error"+ex);
			con = null;
		}
		return (con);
}
public static String DriverTest() {
		String ret = "";
		try {
		Class.forName("com.mysql.jdbc.Driver"); //mysql
		} catch (java.lang.ClassNotFoundException e) {
			System.out.println("Class Not Found Exception!");
		}
		return ("");
	}

public static void InsertTest() throws SQLException,ClassNotFoundException{
		Scanner input = new Scanner(System.in);
		Statement stmt=null;
		Connection conn=null;
		System.out.println("Insertion test..");
		System.out.println("Enter roll<insert>:");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.next();
		
		String SQL = "INSERT INTO STUDENT  VALUES('" + name + "'," + roll + ")";
		conn = DB_Part.getConnection();
		stmt = conn.createStatement();
			stmt.executeUpdate(SQL);
			conn.close();
		}

public static void UpdateTest() throws SQLException,ClassNotFoundException{
			
		Scanner input = new Scanner(System.in);
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		System.out.println("Update test..");
		
		System.out.println("Enter roll<update>:");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.nextLine();
		
		String SQL = "UPDATE  STUDENT set name='"+name+"' where roll='"+roll+"'";
		conn = DB_Part.getConnection();
		stmt = conn.createStatement();
		stmt.executeUpdate(SQL);
		conn.close();	
	}
public static void DeleteTest() throws SQLException,ClassNotFoundException  {
		Scanner input = new Scanner(System.in);
		Statement stmt;		
		System.out.println("Delete  test..");		
		System.out.println("Enter roll<delete>");
		int roll = input.nextInt();
		
		String SQL = "DELETE from STUDENT where roll=" + roll;
		Connection conn = DB_Part.getConnection();
		stmt = conn.createStatement();
		stmt.executeUpdate(SQL);
		conn.close();
}
public static void Prepared_InsertTest() throws SQLException,ClassNotFoundException
	{
		Scanner input = new Scanner(System.in);
		PreparedStatement ps;
		Statement stmt=null;
		
		System.out.println("Enter roll:<prepared>");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.next();
		
		String SQL="INSERT INTO STUDENT  VALUES(?,?)";		
		Connection conn = DB_Part.getConnection();
		ps=conn.prepareStatement(SQL);
		ps.setString(1, name);
		ps.setInt(2,roll);
		ps.executeUpdate();
		conn.close();
	}

public static void  DataInsert_RowDemo() throws SQLException,ClassNotFoundException
	{
		Scanner input = new Scanner(System.in);
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn=null;
		System.out.println("Enter roll:<Insert>");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.next();
		
		String SQL="SELECT * FROM STUDENT";//  WHERE roll="+roll;
		
		conn = DB_Part.getConnection();
		stmt=conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
		rs=stmt.executeQuery(SQL);
		if(rs.next())
			{
				rs.moveToInsertRow();
				rs.updateString("name",name);
				rs.updateInt("roll",roll);
				rs.insertRow();
			        rs.moveToCurrentRow();
			}	
	}


public static void Print() throws SQLException,ClassNotFoundException {
	Connection conn = DB_Part.getConnection();
	Statement stmt = conn.createStatement();
	String sql="Select * from Student";
	ResultSet rs = stmt.executeQuery(sql);
	while (rs.next()) {
				System.out.print(String.valueOf(rs.getInt(2)) + "\t");
				System.out.println(rs.getString(1));
			}
	}
public static void Print_Count() throws SQLException,ClassNotFoundException {
	Connection conn = DB_Part.getConnection();
	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(sql);// static collection
		if (rs.next() == false)
			System.out.println("No records found");
		else{
			System.out.println("USN\tNAME\tMark");
			int count = 0;
			do {
				System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getInt(3));
				count++;
			} while (rs.next());
			System.out.println("Number of rows:" + count);
			}
}
public static void DataUpdateRowDemo() throws SQLException,ClassNotFoundException  
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter roll:<update>");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.next();
		
		String SQL="SELECT name,roll FROM STUDENT  WHERE roll="+roll;
		Statement stmt;
		ResultSet rs=null;
		Connection conn = DB_Part.getConnection();
		stmt=conn.createStatement(0,rs.CONCUR_UPDATABLE);
		rs=stmt.executeQuery(SQL);
		if(rs.next())	{
			rs.updateString("name",name);
			rs.updateRow();
		}
		conn.close();
}
public static void commit_rollback()  {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter roll<update>:");
		int roll = input.nextInt();
		System.out.println("Enter Name:");
		String name = input.next();
		String SQL = "UPDATE  STUDENT set name='"+name+"' where roll='"+roll+"'";
		Connection conn = DB_Part.getConnection();
		try {
			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(SQL);
			System.out.println("Transaction is successfull! ");
			conn.commit();
		
		} catch (SQLException e) {
			System.out.println("Errr.. ");
			if (conn != null) {
				try {
				System.err.println("Transaction is being rolled back ");
				conn.rollback();
				}
				catch(SQLException excep) {
					System.err.print("SQLException: ");
					System.err.println(excep.getMessage());
					}
		}

public static void CallableDemo() throws SQLException ,ClassNotFoundException {
		Connection conn = DB_Part.getConnection();	
		CallableStatement cstmt = null;
		ResultSet rs;
		String SQL = "{call totalRecords ()}";//refer txt file for codes
		cstmt = conn.prepareCall (SQL);
		rs=cstmt.executeQuery();
		while(rs.next()){
			   System.out.println(rs.getInt(1));
		   }
	}

public static void CallableDemo1()  throws SQLException,ClassNotFoundException {
		Connection conn = DB_Part.getConnection();
		CallableStatement cstmt = null;
		ResultSet rs;
		String SQL = "{call Search_Name() }";//refer txt file for codes
		conn.setAutoCommit(false);
		cstmt = conn.prepareCall (SQL);
		rs= cstmt.executeQuery();
		while (rs.next()) {
			         System.out.println(rs.getString(1)+"\t"+rs.getString(2));
		}
	}
public static void CallableDemo2()  throws SQLException,ClassNotFoundException {
		Connection conn = DB_Part.getConnection();
		conn.setAutoCommit(false);
		CallableStatement cstmt = null;
		ResultSet rs;
		String SQL =  "{call Out_Param_Record (?,?)}";
		cstmt = con.prepareCall(SQL);
		cstmt.setInt(1, 2);
		cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
		cstmt.executeQuery();
		while (rs.next()) {
			         System.out.println(cstmt.getString(2));
		}
	}
public static void RollBack_Commit()  
			throws SQLException,ClassNotFoundException {
		Connection conn = DB_Part.getConnection();
		conn.setAutoCommit(false) ;
		PrintRecord();//original
		String SQL = "update student set mark=mark+5";
		PreparedStatement pstmt = conn.prepareStatement(SQL);
		pstmt.executeUpdate();
		PrintRecord();//after update- not reflected auto commit is disabled
		conn.rollback();
		PrintRecord();//after rollback
		
		SQL = "update student set mark=mark+5";
		pstmt = conn.prepareStatement(SQL);
		pstmt.executeUpdate();
		conn.commit(); //update and commit
		PrintRecord();//after commit
		conn.rollback();//rollback
		PrintRecord();//after rollback
		conn.setAutoCommit(true) ;
	}
public static void PrintRecord()  throws SQLException,ClassNotFoundException {
		String SQL="Select * From Student";
		Connection conn = DB_Part.getConnection();
		PreparedStatement pstmt = conn.prepareStatement(SQL);
		ResultSet rs=pstmt.executeQuery();
		System.out.println("-----");
		while (rs.next()){
			System.out.println(	rs.getString(1) + "\t" + 
								rs.getString(2) + "\t" + 
								rs.getInt(3));
		} 
	}
public static void Metadata_Connection() throws ClassNotFoundException, SQLException{
		Connection conn = DB_Part.getConnection();
		DatabaseMetaData dbmd = conn.getMetaData();
		System.out.println("product Name:"+dbmd.getDatabaseProductName());
		System.out.println("User Name:"+dbmd.getUserName()); 
		System.out.println("URL  "+dbmd.getURL()); 
		System.out.println("Scheme:"+dbmd.getSchemas().toString()); 
		System.out.println("Product Name:"+dbmd.getDatabaseProductName());
		System.out.println("Driver Version:" + dbmd.getDriverVersion().toString());
		System.out.println("Driver Name:" + dbmd.getDriverName().toString());
	}
	public static void Metadata_ResultSet() throws ClassNotFoundException, SQLException{
		Connection conn = DB_Part.getConnection();
		Statement stmt = conn.createStatement();
		String SQL="Select * from STUDENT where USN='U1'";
		ResultSet rs = stmt.executeQuery(SQL);
		if (rs.next()) 	System.out.println("Number of rows:"+rs.getRow());// to get the current row number	
		ResultSetMetaData rsmd = rs.getMetaData(); 
		System.out.println("ColumnCount:"+rsmd.getColumnCount());//column count
		System.out.println("I Column:"+rsmd.getColumnLabel(1));//column label
		System.out.println("Size:" + rsmd.getColumnType(1)); //data type of the column-size for varchar(20) 20 is size
		System.out.println("Column Type:" + rsmd.getColumnTypeName(1)); //data type of column 
	}



public static void ResultSet_Insert() throws SQLException, ClassNotFoundException {
		Scanner input = new Scanner(System.in);

		Connection conn;
		Statement stmt;
		ResultSet rs;

		System.out.println("Insertion test using result..");
		System.out.println("Enter USN:");
		String usn = input.next();

		System.out.println("Enter name:");
		String name = input.next();

		System.out.println("Enter mark:");
		int mark = input.nextInt();
		conn = DB_Part.getConnection();

		String query = " SELECT * FROM student ";
		stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		rs = stmt.executeQuery(query);
		rs.moveToInsertRow();
		rs.updateString("USN", usn);
		rs.updateString("Sname", name);
		rs.updateInt("mark", mark);// yes
		rs.insertRow();
		rs.moveToCurrentRow();
		conn.close();
	}



public static void ResultSet_Update() throws SQLException, ClassNotFoundException {
		Scanner input = new Scanner(System.in);

		Connection conn;
		Statement stmt;
		ResultSet rs;

		System.out.println("Update  test using result..");

		System.out.println("Enter USN <record to be modifed>:");

		System.out.println("Enter name:");
		String name = input.next();

		System.out.println("Enter mark:");
		int mark = input.nextInt();
		conn = DB_Part.getConnection();

		String query = " SELECT * FROM student where USN='"+usn+"'";
		stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		rs = stmt.executeQuery(query);
		rs.next(); 
		rs.updateString("Sname", name);
		rs.updateInt("mark", mark);// yes
		rs.updateRow (); 
		conn.close();
	}

public static void ResultSet_Delete() throws SQLException, ClassNotFoundException {
		Scanner input = new Scanner(System.in);

		Connection conn;
		Statement stmt;
		ResultSet rs;

		System.out.println("Deletion test using result..");
		System.out.println("Enter USN<record to be deleted>:");
		String usn = input.next();
		conn = DB_Part.getConnection();

		String query = " SELECT * FROM student where USN='"+usn+"'";
		stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		rs = stmt.executeQuery(query);
		rs.next();
		rs.deleteRow();
		conn.close();
	}
}*/
